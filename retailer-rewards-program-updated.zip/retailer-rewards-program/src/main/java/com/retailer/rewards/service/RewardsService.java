package com.retailer.rewards.service;

import com.retailer.rewards.entities.Rewards;
import com.retailer.rewards.entities.Transactions;

import java.util.List;

public interface RewardsService {

    List<Rewards>  getAllRewards();

    Rewards getAllRewardsByCustId(int customerId);
   List<Transactions> findAllTransactions();

}
