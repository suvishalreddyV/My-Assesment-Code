package com.retailer.rewards.entities;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Rewards {
    private int customerId;
    private int perMonth;
    private int totalPoints;

}
