package com.retailer.rewards.controller;

import com.retailer.rewards.entities.Rewards;
import com.retailer.rewards.entities.Transactions;
import com.retailer.rewards.service.RewardsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class RewardsController {

    @Autowired
    RewardsService rewardsService;

    @GetMapping("/rewards")
    public ResponseEntity<List<Rewards>> getRewards(){
        List<Rewards> allRewards = rewardsService.getAllRewards();
        return  new ResponseEntity<>(allRewards, HttpStatus.OK);
    }

    @GetMapping("/rewards/{customerId}")
    public ResponseEntity<Rewards> getRewards(@PathVariable int customerId){
        Rewards rewards = rewardsService.getAllRewardsByCustId(customerId);
        return  new ResponseEntity<>(rewards, HttpStatus.OK);
    }

    @GetMapping("/transactions")
    public ResponseEntity< List<Transactions>> getTransactions(){
        List<Transactions> transactions = rewardsService.findAllTransactions();
        return  new ResponseEntity<>(transactions, HttpStatus.OK);
    }
}
