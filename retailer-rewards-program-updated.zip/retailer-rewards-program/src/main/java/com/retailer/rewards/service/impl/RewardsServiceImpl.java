package com.retailer.rewards.service.impl;

import com.retailer.rewards.entities.Rewards;
import com.retailer.rewards.entities.Transactions;
import com.retailer.rewards.repository.RewardsRepository;
import com.retailer.rewards.service.RewardsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static java.util.stream.Collectors.groupingBy;

@Service
public class RewardsServiceImpl implements RewardsService {

    @Autowired
    RewardsRepository rewardsRepository;

    @Override
    public Rewards getAllRewardsByCustId(int customerId) {
        Rewards rewards = new Rewards();
        List<Transactions> transactions = rewardsRepository.findAllByCustId( customerId);

        calculateRewards(transactions, rewards);

        return rewards;
    }

    @Override
    public List<Rewards> getAllRewards() {

        List<Rewards> rewardsList = new ArrayList<>();

        List<Transactions> transactionsList = rewardsRepository.findAll();

        calculateAllRewardsList(transactionsList, rewardsList);

        return rewardsList;
    }

    private void calculateAllRewardsList(List<Transactions> transactionsList, List<Rewards> rewardsList) {
        Rewards rewards = new Rewards();

        Map<Integer, List<Transactions>> transactionsGroupByCustId=transactionsList.stream().collect(groupingBy(Transactions::getCustId));

        for (Map.Entry<Integer, List<Transactions>> entry : transactionsGroupByCustId.entrySet()) {
            //System.out.println(entry.getKey().intValue() + ":" + entry.getValue().stream().collect(Collectors.toList()).size());
            rewards = calculateRewards(entry.getValue().stream().collect(Collectors.toList()),new Rewards());
            rewardsList.add(rewards);
        }

    }

    @Override
    public List<Transactions> findAllTransactions() {
        return  rewardsRepository.findAll();
    }

    private Rewards calculateRewards(List<Transactions> transactions, Rewards rewards) {
        int totalPoints = 0;
        for (Transactions obj : transactions) {
            if (obj.getAmount() > 50)
                totalPoints += calTotalPoints(obj.getAmount());
           // System.out.println("totalPoints-->"+totalPoints);
        }
        rewards.setCustomerId(transactions.get(0).getCustId());
        rewards.setTotalPoints(totalPoints);
        //System.out.println("rewards-->"+ rewards);
        //rewards.setPerMonth();
        return rewards;
    }

    private int calTotalPoints(double amount) {

        int onePointCount = (int) (amount % 100);
        int twoPointCount = (int) (amount / 100);
        return onePointCount * 2 + twoPointCount * 50;
    }
}