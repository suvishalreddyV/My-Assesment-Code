package com.retailer.rewards.repository;

import com.retailer.rewards.entities.Transactions;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface RewardsRepository extends JpaRepository<Transactions, Integer> {

    //public List<Transactions> findAlltransactionById();

    @Query(nativeQuery = true, value = "SELECT * FROM retail_rewards.transactions where cust_id=?1 ")
    public  List<Transactions> findAllByCustId(int cuatomerId);

}
