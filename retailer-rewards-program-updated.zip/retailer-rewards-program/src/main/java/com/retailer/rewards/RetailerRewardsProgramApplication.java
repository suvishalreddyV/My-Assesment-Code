package com.retailer.rewards;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RetailerRewardsProgramApplication {

	public static void main(String[] args) {
		SpringApplication.run(RetailerRewardsProgramApplication.class, args);
	}

}
